package VISTA;

public class Proce {
    
    String Nombre;
    int Documento;
    int Edad;
    int Numerocel;
    String Carrera;

    public Proce(String Nombre, int Documento, int Edad, int Numerocel, String Carrera) {
        this.Nombre = Nombre;
        this.Documento = Documento;
        this.Edad = Edad;
        this.Numerocel = Numerocel;
        this.Carrera = Carrera;
    }

    public Proce() {
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getDocumento() {
        return Documento;
    }

    public void setDocumento(int Documento) {
        this.Documento = Documento;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    public int getNumerocel() {
        return Numerocel;
    }

    public void setNumerocel(int Numerocel) {
        this.Numerocel = Numerocel;
    }

    public String getCarrera() {
        return Carrera;
    }

    public void setCarrera(String Carrera) {
        this.Carrera = Carrera;
    }

    @Override
    public String toString() {
        return "Proce{" + "Nombre=" + Nombre + ", Documento=" + Documento + ", Edad=" + Edad + ", Numerocel=" + Numerocel + ", Carrera=" + Carrera + '}';
    }
}
